-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: localhost    Database: internshala
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `core_applicationcounter`
--

DROP TABLE IF EXISTS `core_applicationcounter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `core_applicationcounter` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `applied` int unsigned NOT NULL,
  `under_review` int unsigned NOT NULL,
  `shortlisted` int unsigned NOT NULL,
  `rejected` int unsigned NOT NULL,
  `hired` int unsigned NOT NULL,
  `employer_id` bigint NOT NULL,
  `total` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `employer_id` (`employer_id`),
  CONSTRAINT `core_applicationcoun_employer_id_1ff8aed9_fk_core_empl` FOREIGN KEY (`employer_id`) REFERENCES `core_employerprofile` (`id`),
  CONSTRAINT `core_applicationcounter_chk_1` CHECK ((`applied` >= 0)),
  CONSTRAINT `core_applicationcounter_chk_2` CHECK ((`under_review` >= 0)),
  CONSTRAINT `core_applicationcounter_chk_3` CHECK ((`shortlisted` >= 0)),
  CONSTRAINT `core_applicationcounter_chk_4` CHECK ((`rejected` >= 0)),
  CONSTRAINT `core_applicationcounter_chk_5` CHECK ((`hired` >= 0)),
  CONSTRAINT `core_applicationcounter_chk_6` CHECK ((`total` >= 0))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `core_applicationcounter`
--

LOCK TABLES `core_applicationcounter` WRITE;
/*!40000 ALTER TABLE `core_applicationcounter` DISABLE KEYS */;
INSERT INTO `core_applicationcounter` VALUES (1,2,1,1,0,0,1,4);
/*!40000 ALTER TABLE `core_applicationcounter` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-02-22 20:23:05
