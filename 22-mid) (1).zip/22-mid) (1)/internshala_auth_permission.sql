-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: localhost    Database: internshala
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `auth_permission`
--

DROP TABLE IF EXISTS `auth_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_permission` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `content_type_id` int NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`),
  CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=89 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_permission`
--

LOCK TABLES `auth_permission` WRITE;
/*!40000 ALTER TABLE `auth_permission` DISABLE KEYS */;
INSERT INTO `auth_permission` VALUES (1,'Can add log entry',1,'add_logentry'),(2,'Can change log entry',1,'change_logentry'),(3,'Can delete log entry',1,'delete_logentry'),(4,'Can view log entry',1,'view_logentry'),(5,'Can add permission',2,'add_permission'),(6,'Can change permission',2,'change_permission'),(7,'Can delete permission',2,'delete_permission'),(8,'Can view permission',2,'view_permission'),(9,'Can add group',3,'add_group'),(10,'Can change group',3,'change_group'),(11,'Can delete group',3,'delete_group'),(12,'Can view group',3,'view_group'),(13,'Can add content type',4,'add_contenttype'),(14,'Can change content type',4,'change_contenttype'),(15,'Can delete content type',4,'delete_contenttype'),(16,'Can view content type',4,'view_contenttype'),(17,'Can add session',5,'add_session'),(18,'Can change session',5,'change_session'),(19,'Can delete session',5,'delete_session'),(20,'Can view session',5,'view_session'),(21,'Can add category',6,'add_category'),(22,'Can change category',6,'change_category'),(23,'Can delete category',6,'delete_category'),(24,'Can view category',6,'view_category'),(25,'Can add faq',7,'add_faq'),(26,'Can change faq',7,'change_faq'),(27,'Can delete faq',7,'delete_faq'),(28,'Can view faq',7,'view_faq'),(29,'Can add skill',8,'add_skill'),(30,'Can change skill',8,'change_skill'),(31,'Can delete skill',8,'delete_skill'),(32,'Can view skill',8,'view_skill'),(33,'Can add static page',9,'add_staticpage'),(34,'Can change static page',9,'change_staticpage'),(35,'Can delete static page',9,'delete_staticpage'),(36,'Can view static page',9,'view_staticpage'),(37,'Can add user',10,'add_customuser'),(38,'Can change user',10,'change_customuser'),(39,'Can delete user',10,'delete_customuser'),(40,'Can view user',10,'view_customuser'),(41,'Can add candidate profile',11,'add_candidateprofile'),(42,'Can change candidate profile',11,'change_candidateprofile'),(43,'Can delete candidate profile',11,'delete_candidateprofile'),(44,'Can view candidate profile',11,'view_candidateprofile'),(45,'Can add employer profile',12,'add_employerprofile'),(46,'Can change employer profile',12,'change_employerprofile'),(47,'Can delete employer profile',12,'delete_employerprofile'),(48,'Can view employer profile',12,'view_employerprofile'),(49,'Can add message',13,'add_message'),(50,'Can change message',13,'change_message'),(51,'Can delete message',13,'delete_message'),(52,'Can view message',13,'view_message'),(53,'Can add notification',14,'add_notification'),(54,'Can change notification',14,'change_notification'),(55,'Can delete notification',14,'delete_notification'),(56,'Can view notification',14,'view_notification'),(57,'Can add opportunity',15,'add_opportunity'),(58,'Can change opportunity',15,'change_opportunity'),(59,'Can delete opportunity',15,'delete_opportunity'),(60,'Can view opportunity',15,'view_opportunity'),(61,'Can add application',16,'add_application'),(62,'Can change application',16,'change_application'),(63,'Can delete application',16,'delete_application'),(64,'Can view application',16,'view_application'),(65,'Can add saved opportunity',17,'add_savedopportunity'),(66,'Can change saved opportunity',17,'change_savedopportunity'),(67,'Can delete saved opportunity',17,'delete_savedopportunity'),(68,'Can view saved opportunity',17,'view_savedopportunity'),(69,'Can add TOTP device',18,'add_totpdevice'),(70,'Can change TOTP device',18,'change_totpdevice'),(71,'Can delete TOTP device',18,'delete_totpdevice'),(72,'Can view TOTP device',18,'view_totpdevice'),(73,'Can add email device',19,'add_emaildevice'),(74,'Can change email device',19,'change_emaildevice'),(75,'Can delete email device',19,'delete_emaildevice'),(76,'Can view email device',19,'view_emaildevice'),(77,'Can add job',20,'add_job'),(78,'Can change job',20,'change_job'),(79,'Can delete job',20,'delete_job'),(80,'Can view job',20,'view_job'),(81,'Can add application counter',21,'add_applicationcounter'),(82,'Can change application counter',21,'change_applicationcounter'),(83,'Can delete application counter',21,'delete_applicationcounter'),(84,'Can view application counter',21,'view_applicationcounter'),(85,'Can add job application',22,'add_jobapplication'),(86,'Can change job application',22,'change_jobapplication'),(87,'Can delete job application',22,'delete_jobapplication'),(88,'Can view job application',22,'view_jobapplication');
/*!40000 ALTER TABLE `auth_permission` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-02-22 20:23:04
