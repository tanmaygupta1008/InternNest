-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: localhost    Database: internshala
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `django_session`
--

DROP TABLE IF EXISTS `django_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_expire_date_a5c62663` (`expire_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_session`
--

LOCK TABLES `django_session` WRITE;
/*!40000 ALTER TABLE `django_session` DISABLE KEYS */;
INSERT INTO `django_session` VALUES ('226uzna4h7m0ff1iiqovlzor53hlw73d','.eJxVjEEOwiAQRe_C2hAYoFNcuvcMZGBAqoYmpV0Z765NutDtf-_9lwi0rTVsPS9hYnEWRpx-t0jpkdsO-E7tNss0t3WZotwVedAurzPn5-Vw_w4q9fqtbcxaaVvYOPaDG20ZDBSFABodEpWMxlpCZJdZEcBIDNr4wsp79Em8P8r3N0w:1thYEC:5sdJRt9pFs-0qdhcojJWPA9R5qkMznYGUhOfOaAblOk','2025-02-24 18:09:52.051054'),('bnn1n7jof6lg7uv0e1udb57gv60q1f3k','.eJxVjDsOwyAQRO9CHSE-ZrFSps8Z0LILwUkEkrErK3ePLblIypn3ZjYRcF1KWHuaw8TiKrS4_HYR6ZXqAfiJ9dEktbrMU5SHIk_a5b1xet9O9--gYC_7OmqfLToCHo2ytCcdR4PAigm8coSZslXeAICzAxvyhqIi5iHbiEl8vum6OHY:1tfO3G:JvtRvsR-3ZZkOjKtye81_yTdDGSj_fz9RuVGZY5b4G0','2025-02-18 18:53:38.045184'),('e3xcv88o9mvrdkaxmkd4zao8oc6s3tg2','.eJxVjEEOwiAQRe_C2hA61AFcuu8ZyDCAVA0kpV0Z765NutDtf-_9l_C0rcVvPS1-juIiQJx-t0D8SHUH8U711iS3ui5zkLsiD9rl1GJ6Xg_376BQL99aGUMWXBitG8cINg3aMiMYQAwJ4tlGHggcKqeD1pQBUlZKIWSHjCzeH720Nxg:1tftn8:NGDPXv6DQTRhfEI0Z6ePkOKNjiA5YKsLhfltZ8URPWU','2025-02-20 04:47:06.179252'),('hw14w2gmnyzu5rzkc0dnzeonkldk4pp7','eyJlbWFpbCI6InZpcmFqcHJhYmh1NDdAZ21haWwuY29tIiwicGFzc3dvcmQiOiIxMjM0IiwidXNlcl90eXBlIjoiRW1wbG95ZXIifQ:1tgq6J:Wcd2Usvm2fich0IH7fRmDeqj2sLHbD7A7T_kXlIEm3w','2025-02-22 19:02:47.826511'),('ync376pfgeyzwyflgqvj6kuuac6c1miw','.eJxVjDsOwyAQRO9CHSE-ZrFSps8Z0LILwUkEkrErK3ePLblIypn3ZjYRcF1KWHuaw8TiKrS4_HYR6ZXqAfiJ9dEktbrMU5SHIk_a5b1xet9O9--gYC_7OmqfLToCHo2ytCcdR4PAigm8coSZslXeAICzAxvyhqIi5iHbiEl8vum6OHY:1tgOym:NfDa9I5cAyJeWof0Ku80Fv4_IlB30sO7vCh8UkUKo-I','2025-02-21 14:05:12.744798');
/*!40000 ALTER TABLE `django_session` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-02-17  0:25:32
