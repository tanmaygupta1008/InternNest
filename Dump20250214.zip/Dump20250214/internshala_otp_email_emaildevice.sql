-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: localhost    Database: internshala
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `otp_email_emaildevice`
--

DROP TABLE IF EXISTS `otp_email_emaildevice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `otp_email_emaildevice` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `confirmed` tinyint(1) NOT NULL,
  `user_id` bigint NOT NULL,
  `token` varchar(16) DEFAULT NULL,
  `valid_until` datetime(6) NOT NULL,
  `email` varchar(254) DEFAULT NULL,
  `throttling_failure_count` int unsigned NOT NULL,
  `throttling_failure_timestamp` datetime(6) DEFAULT NULL,
  `last_generated_timestamp` datetime(6) DEFAULT NULL,
  `created_at` datetime(6) DEFAULT NULL,
  `last_used_at` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `otp_email_emaildevice_user_id_0215c274_fk_core_customuser_id` (`user_id`),
  CONSTRAINT `otp_email_emaildevice_user_id_0215c274_fk_core_customuser_id` FOREIGN KEY (`user_id`) REFERENCES `core_customuser` (`id`),
  CONSTRAINT `otp_email_emaildevice_chk_1` CHECK ((`throttling_failure_count` >= 0))
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `otp_email_emaildevice`
--

LOCK TABLES `otp_email_emaildevice` WRITE;
/*!40000 ALTER TABLE `otp_email_emaildevice` DISABLE KEYS */;
INSERT INTO `otp_email_emaildevice` VALUES (1,'default',1,1,NULL,'2025-02-12 20:23:58.037247',NULL,0,NULL,NULL,'2025-02-08 18:03:48.288064','2025-02-12 20:23:58.043237'),(2,'VIRAJ PRABHU',1,3,'388594','2025-02-13 18:37:40.492965','iamlegitop47@gmail.com',0,NULL,'2025-02-13 18:32:40.492965','2025-02-09 19:22:39.699434','2025-02-13 18:30:50.596693'),(3,'siddhant',1,2,NULL,'2025-02-11 13:57:40.790396',NULL,0,NULL,NULL,'2025-02-11 13:57:40.796379',NULL),(4,'tanmay',1,4,NULL,'2025-02-11 13:58:00.934704',NULL,0,NULL,NULL,'2025-02-11 13:58:00.939350',NULL),(5,'arshvir',1,5,NULL,'2025-02-11 14:00:07.388144',NULL,0,NULL,NULL,'2025-02-11 14:00:07.394191',NULL);
/*!40000 ALTER TABLE `otp_email_emaildevice` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-02-14  0:32:59
